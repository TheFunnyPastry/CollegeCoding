import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
import tensorflow.keras.backend as K

# Generate training data
def target_function(x):
    return np.sin(np.pi/2 * x)

# Generate 200 training samples
np.random.seed(42)
x_train = np.random.uniform(-2, 2, 200).reshape(-1, 1)
y_train = target_function(x_train)

# Create a model with minimal neurons
model = Sequential([
    Dense(8, activation='relu', input_shape=(1,)),
    Dense(8, activation='relu'),
    Dense(1, activation='linear')
])

# Compile the model
model.compile(optimizer=Adam(learning_rate=0.01), loss='mse')

# Custom callback to track errors
class ErrorTracker(tf.keras.callbacks.Callback):
    def __init__(self, x_test):
        super().__init__()
        self.x_test = x_test
        self.y_test = target_function(x_test)
        self.train_losses = []
        self.avg_errors = []
        self.max_errors = []
        self.hamming_distances = []
        self.prev_patterns = None

    def on_epoch_begin(self, epoch, logs=None):
        if epoch > 0:  # Skip first epoch
            self.prev_patterns = self.get_activation_patterns(self.x_train)

    def on_epoch_end(self, epoch, logs=None):
        # Record training loss
        self.train_losses.append(logs['loss'])

        # Calculate test errors
        y_pred = self.model.predict(self.x_test, verbose=0)
        errors = np.abs(y_pred.flatten() - self.y_test.flatten())
        self.avg_errors.append(np.mean(errors))
        self.max_errors.append(np.max(errors))

        # Calculate Hamming distance for activation patterns
        if epoch > 0:  # Skip first epoch
            current_patterns = self.get_activation_patterns(self.x_train)
            hamming_dist = self.compute_hamming_distance(self.prev_patterns, current_patterns)
            self.hamming_distances.append(hamming_dist)

        print(f"Epoch {epoch+1}: Loss={logs['loss']:.4f}, Avg Error={self.avg_errors[-1]:.4f}, Max Error={self.max_errors[-1]:.4f}")
        if epoch > 0:
            print(f"Hamming Distance: {self.hamming_distances[-1]}")

    def get_activation_patterns(self, inputs):
        # Get activation patterns for all ReLU neurons
        patterns = []
        for layer_idx in range(2):  # We have 2 ReLU layers
            # Create a function to get activations
            get_activations = K.function([self.model.input],
                                         [self.model.layers[layer_idx].output])
            activations = get_activations([inputs])[0]
            # Convert to binary patterns (1 for positive, 0 for zero/negative)
            binary_patterns = (activations > 0).astype(int)
            patterns.append(binary_patterns)
        return patterns

    def compute_hamming_distance(self, patterns1, patterns2):
        total_distance = 0
        for layer_idx in range(len(patterns1)):
            # XOR gives 1 where bits differ
            diff = np.logical_xor(patterns1[layer_idx], patterns2[layer_idx])
            total_distance += np.sum(diff)
        return total_distance

# Generate test data for visualization
x_test = np.linspace(-2, 2, 1000).reshape(-1, 1)

# Create callback
error_tracker = ErrorTracker(x_test)

# Train the model
history = model.fit(
    x_train, y_train,
    epochs=100,
    batch_size=32,
    verbose=0,
    callbacks=[error_tracker]
)

# Plot results
plt.figure(figsize=(15, 10))

# Plot 1: Training error and test errors
plt.subplot(2, 2, 1)
plt.plot(error_tracker.train_losses, label='Training Loss')
plt.plot(error_tracker.avg_errors, label='Avg Test Error')
plt.plot(error_tracker.max_errors, label='Max Test Error')
plt.xlabel('Epoch')
plt.ylabel('Error')
plt.legend()
plt.title('Training and Test Errors')

# Plot 2: True function vs. Neural Network approximation
plt.subplot(2, 2, 2)
y_pred = model.predict(x_test)
plt.plot(x_test, target_function(x_test), 'b-', label='True Function')
plt.plot(x_test, y_pred, 'r--', label='Neural Network')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.title('Function Approximation')

# Plot 3: Activation regions
plt.subplot(2, 2, 3)
# Get activation patterns for visualization
x_vis = np.linspace(-2, 2, 1000).reshape(-1, 1)
patterns = []

# Get activation patterns for all layers
for layer_idx in range(2):  # 2 ReLU layers
    get_activations = K.function([model.input], [model.layers[layer_idx].output])
    activations = get_activations([x_vis])[0]
    binary_patterns = (activations > 0).astype(int)
    patterns.append(binary_patterns)

# Combine patterns from all layers
combined_patterns = np.concatenate([patterns[0], patterns[1]], axis=1)

# Find unique patterns and their boundaries
unique_patterns = []
boundaries = []
current_pattern = combined_patterns[0]
unique_patterns.append(tuple(current_pattern.flatten()))

for i in range(1, len(combined_patterns)):
    if not np.array_equal(combined_patterns[i], current_pattern):
        boundaries.append(x_vis[i][0])
        current_pattern = combined_patterns[i]
        unique_patterns.append(tuple(current_pattern.flatten()))

# Plot the activation regions
colors = plt.cm.tab10(np.linspace(0, 1, len(unique_patterns)))
current_region = 0

for i in range(len(boundaries) + 1):
    if i == 0:
        plt.axvspan(-2, boundaries[0], alpha=0.3, color=colors[current_region])
        plt.text(-2 + (boundaries[0] + 2) / 2, 0, f"Pattern {current_region}",
                 ha='center', va='center')
    elif i == len(boundaries):
        plt.axvspan(boundaries[-1], 2, alpha=0.3, color=colors[current_region])
        plt.text(boundaries[-1] + (2 - boundaries[-1]) / 2, 0, f"Pattern {current_region}",
                 ha='center', va='center')
    else:
        plt.axvspan(boundaries[i-1], boundaries[i], alpha=0.3, color=colors[current_region])
        plt.text(boundaries[i-1] + (boundaries[i] - boundaries[i-1]) / 2, 0,
                 f"Pattern {current_region}", ha='center', va='center')
    current_region += 1

plt.xlabel('x')
plt.title('Activation Regions')

# Plot 4: Hamming distance over epochs
plt.subplot(2, 2, 4)
plt.plot(range(1, len(error_tracker.hamming_distances) + 1), error_tracker.hamming_distances)
plt.xlabel('Epoch')
plt.ylabel('Hamming Distance')
plt.title('Activation Pattern Changes (Hamming Distance)')

plt.tight_layout()
plt.savefig('neural_network_approximation_results.png')
plt.show()

# Print activation patterns for each region
print("\nActivation Patterns for Each Region:")
for i, pattern in enumerate(unique_patterns):
    print(f"Region {i}: {pattern}")

# Created/Modified files during execution:
print("neural_network_approximation_results.png")